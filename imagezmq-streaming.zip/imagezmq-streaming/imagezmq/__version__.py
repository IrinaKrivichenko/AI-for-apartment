# populates fields for >>>help(imagezmq)
__title__ = 'imagezmq'
__description__ = 'Transporting OpenCV images via ZMQ'
__url__ = ''
__version__ = '0.0.2'
__author__ = 'Jeff Bass'
__author_email__ = 'jeff@yin-yan-ranch.com'
__license__ = 'MIT 1.0'
__copyright__ = 'Copyright 2017 Jeff Bass'
